package com.cognizant.dao;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Company;
import com.cognizant.entity.SExchange;
@Repository
public interface AdminDao extends CrudRepository<Company, Serializable> {

	Company findByCompanyId(long companyId);
	
	SExchange save(SExchange sExchange);

	void deleteBycompanyId(long companyId);

}	

