package com.cognizant.service;

import com.cognizant.entity.Company;
import com.cognizant.entity.SExchange;

public interface AdminService {
	Company save(Company company); 
	void deleteBycompanyId(long companyId);
	SExchange save(SExchange sExchange);
	Company findByCompanyId(long companyId);

}
