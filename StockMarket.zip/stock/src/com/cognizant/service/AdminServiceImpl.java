package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDao;
import com.cognizant.entity.Company;
import com.cognizant.entity.SExchange;

@Service
public class AdminServiceImpl implements AdminService {

@Autowired
private AdminDao admindao;

@Override
public Company save(Company company)
{
	return admindao.save(company);
}

@Override
public void deleteBycompanyId(long companyId) {
	admindao.delete(companyId);
	
}

@Override
public SExchange save(SExchange sExchange) {
	
	return admindao.save(sExchange);
}

@Override
public Company findByCompanyId(long companyId) {

	return admindao.findByCompanyId(companyId);

}

}
