package com.cognizant.controller;

import java.util.Date;

import javax.servlet.ServletException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.entity.Company;
import com.cognizant.entity.SExchange;
import com.cognizant.entity.User;
import com.cognizant.service.AdminService;
import com.cognizant.service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@RequestMapping("/admin")

public class AdminController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AdminService AdminService;
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@RequestBody User login) throws ServletException {

		String jwtToken = "";

		if (login.getUserName() == null || login.getPassword() == null) {
			throw new ServletException("Please fill in username and password");
		}

		String username = login.getUserName();
		String password = login.getPassword();

		User user = userService.findUser(username, password);

		if (user == null) {
			throw new ServletException("User email not found.");
		}

		String pwd = user.getPassword();

		if (!password.equals(pwd)) {
			throw new ServletException("Invalid login. Please check your name and password.");
		}

		jwtToken = Jwts.builder().setSubject(username).claim("roles", "user").setIssuedAt(new Date())
				.signWith(SignatureAlgorithm.HS256, "secretkey").compact();

		return jwtToken;
	}
	
	@RequestMapping(value = "/add/company", method = RequestMethod.POST)
	public Company addCompany(@RequestBody Company company) {
		return AdminService.save(company);
	}

	@RequestMapping(value = "/update/company/details", method = RequestMethod.POST)
	public Company updateCompanyDetails(@RequestBody Company company) {
		return AdminService.save(company);
	}
	
	@RequestMapping(value = "/edit/company/database/delete", method = RequestMethod.POST)
	public String deleteCompanyDetails(@RequestParam int companyId) {
		 AdminService.deleteBycompanyId(companyId);
		return "Company Deleted";
	}
	
	@RequestMapping(value = "/add/sExchange", method = RequestMethod.POST)
	public SExchange addsExchange(@RequestBody SExchange sExchange) {
		return AdminService.save(sExchange);
	}
	
	@RequestMapping(value = "/update/sExchange/details", method = RequestMethod.POST)
	public SExchange updatesExchange(@RequestBody SExchange sExchange) {
		return AdminService.save(sExchange);
	}
	
	@RequestMapping(value = "/company/database/search", method = RequestMethod.POST)
	public Company searchCompany(@RequestBody Company company) {		
		
		long companyId=company.getCompanyId();
		return AdminService.findByCompanyId(companyId);
	}
	
	@RequestMapping(value = "/block/user", method = RequestMethod.POST)
	@Transactional
	public String blockUser(@RequestParam long id)
	{
		User user=new User();
		user=userService.findById(id);
		if(user.isIsblock()==true)
		{
			return "User is blocked";
		}
		else
		{
			user.setIsblock(true);
			
			return "User is now blocked";
		}
	}
	
	@RequestMapping(value = "/block/company", method = RequestMethod.POST)
	@Transactional
	public String blockCompany(@RequestParam long companyId)
	{
		Company company=new Company();
		company=AdminService.findByCompanyId(companyId);
		if(company.isCompanyBlock()==true)
		{
			return "Company is blocked";
		}
		else
		{
			company.setCompanyBlock(true);
			
			return "Company is now blocked";
		}
	}
	
	

	
}
